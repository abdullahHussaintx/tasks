const axios = require("axios");
const fs = require("fs");
const path = require("path");

const redditUrl = "https://www.reddit.com/r/popular.json";
const stateFile = path.join(__dirname, "state.json");

let lastPosts = [];

const loadState = () => {
  try {
    const data = fs.readFileSync(stateFile);
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
};

const saveState = (posts) => {
  fs.writeFileSync(stateFile, JSON.stringify(posts, null, 2));
};

const fetchPosts = async () => {
  const response = await axios.get(redditUrl);
  return response.data.data.children.map((post) => ({
    id: post.data.id,
    title: post.data.title,
    score: post.data.score,
  }));
};

const comparePosts = (newPosts) => {
  const newIds = newPosts.map((post) => post.id);
  const oldIds = lastPosts.map((post) => post.id);

  const newPostsAdded = newPosts.filter((post) => !oldIds.includes(post.id));
  const postsRemoved = lastPosts.filter((post) => !newIds.includes(post.id));
  const voteChanges = newPosts
    .map((newPost) => {
      const oldPost = lastPosts.find((post) => post.id === newPost.id);
      if (oldPost) {
        const voteChange = newPost.score - oldPost.score;
        return {
          title: newPost.title,
          change: voteChange,
        };
      }
      return null;
    })
    .filter((change) => change);

  console.log("New posts since last execution:");
  newPostsAdded.forEach((post) => console.log(`- ${post.title}`));

  console.log("\nPosts that are no longer in the top:");
  postsRemoved.forEach((post) => console.log(`- ${post.title}`));

  console.log("\nVote count changes:");
  voteChanges.forEach((change) =>
    console.log(
      `- ${change.title}: ${change.change > 0 ? "+" : ""}${change.change}`
    )
  );
};

const main = async () => {
  lastPosts = loadState();
  const newPosts = await fetchPosts();
  comparePosts(newPosts);
  saveState(newPosts);
};

main().catch(console.error);
